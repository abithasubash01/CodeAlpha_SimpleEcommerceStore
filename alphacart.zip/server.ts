import express from "express";
import path from "path";
import fs from "fs/promises";
import { createServer as createViteServer } from "vite";
import { Product, Order, User } from "./src/types";

// Define Database file
const DB_FILE = path.join(process.cwd(), "db.json");

interface Database {
  products: Product[];
  users: (User & { passwordHash: string })[];
  orders: Order[];
}

// Seed data
const SEED_PRODUCTS: Product[] = [
  {
    id: "prod-1",
    name: "Studio Headphones Pro",
    description: "Premium over-ear studio headphones designed with a high-fidelity sound signature, active noise cancellation, and a sleek physical posture. Memory foam ear cushions ensure ultimate listening comfort over hours of production.",
    category: "Electronics",
    price: 249.00,
    stock: 12,
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=80",
    rating: { rate: 4.8, count: 42 },
    features: ["40mm Custom Drivers", "Active Hybrid ANC", "50-Hour Battery Life", "Ultra-soft memory foam earcups"]
  },
  {
    id: "prod-2",
    name: "Wireless Mechanical Keyboard",
    description: "Wireless mechanical keyboard offering signature physical responsiveness with clicky brown switches, custom vintage style keycaps, and a strong anodized aluminum baseplate.",
    category: "Electronics",
    price: 159.00,
    stock: 8,
    image: "https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=800&auto=format&fit=crop&q=80",
    rating: { rate: 4.7, count: 31 },
    features: ["Tactile Hot-swappable Switches", "Anodized Aluminum Frame", "Bluetooth / 2.4Ghz / USB-C", "Mac & Windows Native Layout"]
  },
  {
    id: "prod-3",
    name: "Minimal Leather Craft Wallet",
    description: "Individually handcrafted from premium vegetable-tanned full-grain leather, this minimalist card sleeve keeps a slim pocket profile while holding up to 8 cards and folded currency.",
    category: "Accessories",
    price: 65.00,
    stock: 25,
    image: "https://images.unsplash.com/photo-1627124765135-56c64606771e?w=800&auto=format&fit=crop&q=80",
    rating: { rate: 4.9, count: 18 },
    features: ["Italian Full-Grain Leather", "Hand-stitched durability", "RFID blocking guard", "Subtle embossed brand detailing"]
  },
  {
    id: "prod-4",
    name: "Double-Walled Thermal Flask",
    description: "Vacuum-sealed double-walled food grade stainless steel container that isolates temperatures, keeping hot tea warm for 12 hours or cold refreshment chilled for 24 hours.",
    category: "Lifestyle",
    price: 38.00,
    stock: 30,
    image: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=800&auto=format&fit=crop&q=80",
    rating: { rate: 4.5, count: 68 },
    features: ["18/8 Pro-Grade Stainless Steel", "BPA-Free & Leakproof cap", "Powder-coated non-slip grip", "Wide mouth for ice insertion"]
  },
  {
    id: "prod-5",
    name: "Concrete Desk Organizer Set",
    description: "Molded from architectural concrete and polished to a smooth stone finish, this two-piece desk weight and organizer system keeps writing tools and notebooks orderly with weighted stability.",
    category: "Home Decor",
    price: 45.00,
    stock: 15,
    image: "https://images.unsplash.com/photo-1513151233558-d860c5398176?w=800&auto=format&fit=crop&q=80",
    rating: { rate: 4.6, count: 24 },
    features: ["High-durability architectural concrete", "Soft felt base to protect wooden surfaces", "Optimized slots for stationery", "Weighted paperweight mechanics"]
  },
  {
    id: "prod-6",
    name: "Smart Ambient Lamp Accent",
    description: "Diffused multi-spectral ambient LED light source. Generates eye-safe warm lighting for desks and bedside setups. Features physical dimmer slider control and customizable temperature states.",
    category: "Home Decor",
    price: 89.00,
    stock: 10,
    image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=800&auto=format&fit=crop&q=80",
    rating: { rate: 4.4, count: 16 },
    features: ["Continuously variable physical dimming", "Stepless color temperature (2200K - 6500K)", "Minimalist birch wood frame", "Standard USB-C power interface"]
  },
  {
    id: "prod-7",
    name: "Felted Wool Desk Mat",
    description: "An elegant protective surface handcrafted from authentic heavy-weight merino wool felt. Softens desk acoustics, prevents surface scratching, and adds tactile comfort to workspace devices.",
    category: "Lifestyle",
    price: 55.00,
    stock: 20,
    image: "https://images.unsplash.com/photo-1632292224971-0d45778bd364?w=800&auto=format&fit=crop&q=80",
    rating: { rate: 4.8, count: 52 },
    features: ["100% Genuine Merino Wool Felt", "Natural dirt and water resistance", "Hand-locked perimeter stitching", "Breathable thermal insulation layer"]
  },
  {
    id: "prod-8",
    name: "Ergonomic Precision Wireless Mouse",
    description: "Meticulously designed wireless mouse supporting a sculpted form that aligns perfectly with hands. Houses a high-fidelity optical sensor for seamless glide tracking across desk pads.",
    category: "Electronics",
    price: 79.00,
    stock: 14,
    image: "https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?w=800&auto=format&fit=crop&q=80",
    rating: { rate: 4.6, count: 39 },
    features: ["Ergonomic thumb grip profile", "8000 DPI hyper-accurate sensor", "Surgical steel precision scroll-wheel", "Multi-device quick switch pairing"]
  }
];

// Load and save helper functions
async function readDatabase(): Promise<Database> {
  try {
    const data = await fs.readFile(DB_FILE, "utf-8");
    return JSON.parse(data);
  } catch (err) {
    // If not found or error, seed database
    const initialDb: Database = {
      products: SEED_PRODUCTS,
      users: [
        {
          id: "user-1",
          username: "customer",
          email: "customer@example.com",
          name: "Abitha Subash",
          address: "123 Main Street, Bangalore, India",
          passwordHash: "password123" // Simplified plain comparison for basic registration/auth
        }
      ],
      orders: []
    };
    await writeDatabase(initialDb);
    return initialDb;
  }
}

async function writeDatabase(db: Database): Promise<void> {
  await fs.writeFile(DB_FILE, JSON.stringify(db, null, 2), "utf-8");
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware for body parsing
  app.use(express.json());

  // API: Get products
  app.get("/api/products", async (req, res) => {
    try {
      const db = await readDatabase();
      res.json(db.products);
    } catch (error) {
      res.status(500).json({ error: "Failed to load products" });
    }
  });

  // API: Get single product
  app.get("/api/products/:id", async (req, res) => {
    try {
      const db = await readDatabase();
      const product = db.products.find((p) => p.id === req.params.id);
      if (!product) {
        res.status(404).json({ error: "Product not found" });
        return;
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to load product detail" });
    }
  });

  // API: Register User
  app.post("/api/auth/register", async (req, res) => {
    try {
      const { username, email, password, name, address } = req.body;
      if (!username || !email || !password) {
        res.status(400).json({ error: "Username, email, and password are required" });
        return;
      }

      const db = await readDatabase();
      const userExists = db.users.some(
        (u) => u.username === username || u.email === email
      );

      if (userExists) {
        res.status(400).json({ error: "Username or Email already registered" });
        return;
      }

      const newUser = {
        id: `user-${Date.now()}`,
        username,
        email,
        name: name || username,
        address: address || "",
        passwordHash: password
      };

      db.users.push(newUser);
      await writeDatabase(db);

      // Respond with sanitized user data
      const { passwordHash, ...sanitizedUser } = newUser;
      res.status(201).json({
        user: sanitizedUser,
        token: `mock-jwt-token-${newUser.id}`
      });
    } catch (error) {
      res.status(500).json({ error: "Registration failed" });
    }
  });

  // API: Login User
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { credential, password } = req.body;
      if (!credential || !password) {
        res.status(400).json({ error: "Credentials and password are required" });
        return;
      }

      const db = await readDatabase();
      const user = db.users.find(
        (u) => (u.username === credential || u.email === credential) && u.passwordHash === password
      );

      if (!user) {
        res.status(401).json({ error: "Invalid credentials" });
        return;
      }

      const { passwordHash, ...sanitizedUser } = user;
      res.json({
        user: sanitizedUser,
        token: `mock-jwt-token-${user.id}`
      });
    } catch (error) {
      res.status(500).json({ error: "Login failed" });
    }
  });

  // API: Process Order
  app.post("/api/orders", async (req, res) => {
    try {
      const { userId, items, shippingAddress, paymentMethod, totalAmount } = req.body;

      if (!items || !items.length || !shippingAddress || !paymentMethod) {
        res.status(400).json({ error: "Incomplete order specifications" });
        return;
      }

      const db = await readDatabase();

      // Check stock levels first
      for (const item of items) {
        const product = db.products.find((p) => p.id === item.productId);
        if (!product) {
          res.status(400).json({ error: `Product ${item.name} could not be validated.` });
          return;
        }
        if (product.stock < item.quantity) {
          res.status(400).json({
            error: `Insufficient stock for product '${product.name}'. Selected: ${item.quantity}, Stock: ${product.stock}`
          });
          return;
        }
      }

      // Deduct stock levels elements
      for (const item of items) {
        const product = db.products.find((p) => p.id === item.productId)!;
        product.stock -= item.quantity;
      }

      // Create physical receipt
      const order: Order = {
        id: `ord-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
        userId: userId || "anonymous",
        items,
        shippingAddress,
        paymentMethod,
        totalAmount,
        createdAt: new Date().toISOString(),
        status: "Processing"
      };

      db.orders.push(order);
      await writeDatabase(db);

      res.status(201).json(order);
    } catch (error: any) {
      res.status(500).json({ error: "Order compilation failed: " + error.message });
    }
  });

  // API: Fetch historical orders for a user
  app.get("/api/orders/user/:userId", async (req, res) => {
    try {
      const db = await readDatabase();
      const userOrders = db.orders.filter((o) => o.userId === req.params.userId);
      res.json(userOrders);
    } catch (error) {
      res.status(500).json({ error: "Failed to retrieve order logs" });
    }
  });

  // API: Reset DB Helper
  app.post("/api/db/reset", async (req, res) => {
    try {
      const db: Database = {
        products: SEED_PRODUCTS,
        users: [
          {
            id: "user-1",
            username: "customer",
            email: "customer@example.com",
            name: "Abitha Subash",
            address: "123 Main Street, Bangalore, India",
            passwordHash: "password123"
          }
        ],
        orders: []
      };
      await writeDatabase(db);
      res.json({ success: true, message: "Database reset to clean seeds configuration." });
    } catch (error) {
      res.status(500).json({ error: "Failed to reset database" });
    }
  });

  // Vite Integration & Asset Route Layer
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Production serving static files
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`E-Commerce Server active at http://0.0.0.0:${PORT}`);
  });
}

startServer();
