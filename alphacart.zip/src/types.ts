export interface Product {
  id: string;
  name: string;
  description: string;
  category: string;
  price: number;
  stock: number;
  image: string;
  rating?: {
    rate: number;
    count: number;
  };
  features?: string[];
}

export interface User {
  id: string;
  username: string;
  email: string;
  name?: string;
  address?: string;
}

export interface AuthState {
  user: User | null;
  token: string | null;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Order {
  id: string;
  userId: string;
  items: {
    productId: string;
    name: string;
    price: number;
    quantity: number;
    image: string;
  }[];
  shippingAddress: {
    fullName: string;
    address: string;
    city: string;
    postalCode: string;
    country: string;
  };
  paymentMethod: string;
  totalAmount: number;
  createdAt: string;
  status: 'Pending' | 'Processing' | 'Shipped' | 'Completed';
}
