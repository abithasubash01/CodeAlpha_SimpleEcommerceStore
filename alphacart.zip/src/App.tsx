import { useState, useEffect } from "react";
import { ArrowUpRight, ShieldCheck, Box, RefreshCw, ShoppingBag, Eye, Plus, Info, AlertCircle } from "lucide-react";
import { Product, CartItem, User, Order } from "./types";
import Navbar from "./components/Navbar";
import ProductCard from "./components/ProductCard";
import ProductDetailModal from "./components/ProductDetailModal";
import CartDrawer from "./components/CartDrawer";
import AuthModal from "./components/AuthModal";
import OrderHistory from "./components/OrderHistory";

export default function App() {
  // DB Product States
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Authentication states
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem("auth_user");
    return saved ? JSON.parse(saved) : null;
  });
  const [token, setToken] = useState<string | null>(() => {
    return localStorage.getItem("auth_token") || null;
  });

  // Shopping Cart states
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem("user_cart");
    return saved ? JSON.parse(saved) : [];
  });

  // Filters & Search states
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  // Modal Open states
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Feedback notifications
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Fetch products immediately on component mount
  const fetchProducts = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const res = await fetch("/api/products");
      if (!res.ok) throw new Error("Catalog load failed.");
      const data = await res.json();
      setProducts(data);
      
      // Get unique categories list dynamically
      const uniqueCats = Array.from(new Set(data.map((p: Product) => p.category))) as string[];
      setCategories(uniqueCats);
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to load catalog essentials.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  // Sync state helpers to clean localStorage
  useEffect(() => {
    if (user) {
      localStorage.setItem("auth_user", JSON.stringify(user));
    } else {
      localStorage.removeItem("auth_user");
    }
  }, [user]);

  useEffect(() => {
    if (token) {
      localStorage.setItem("auth_token", token);
    } else {
      localStorage.removeItem("auth_token");
    }
  }, [token]);

  useEffect(() => {
    localStorage.setItem("user_cart", JSON.stringify(cartItems));
  }, [cartItems]);

  // Auth Action Handlers
  const handleAuthSuccess = (authUser: User, authToken: string) => {
    setUser(authUser);
    setToken(authToken);
    showToast(`Welcome back, ${authUser.name || authUser.username}!`);
  };

  const handleLogout = () => {
    setUser(null);
    setToken(null);
    showToast("Signed out successfully.");
  };

  // Toast Trigger Helper
  const showToast = (message: string) => {
    setToastMessage(message);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Cart Operation Handlers
  const handleAddToCart = (product: Product, quantity = 1) => {
    setCartItems((prevItems) => {
      const existing = prevItems.find((item) => item.product.id === product.id);
      
      if (existing) {
        const updatedQty = existing.quantity + quantity;
        if (updatedQty > product.stock) {
          showToast(`Cannot increase: Only ${product.stock} items left in stock.`);
          return prevItems;
        }
        showToast(`Updated cart: ${product.name} (Qty: ${updatedQty})`);
        return prevItems.map((item) =>
          item.product.id === product.id ? { ...item, quantity: updatedQty } : item
        );
      }
      
      showToast(`Added ${product.name} to cart.`);
      return [...prevItems, { product, quantity }];
    });
  };

  const handleUpdateCartQuantity = (product: Product, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveFromCart(product);
      return;
    }

    if (quantity > product.stock) {
      showToast(`Cannot adjust. Only ${product.stock} units currently left inside database.`);
      return;
    }

    setCartItems((prevItems) =>
      prevItems.map((item) =>
        item.product.id === product.id ? { ...item, quantity } : item
      )
    );
  };

  const handleRemoveFromCart = (product: Product) => {
    setCartItems((prevItems) => prevItems.filter((item) => item.product.id !== product.id));
    showToast(`Removed ${product.name} from cart.`);
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  // Success Checkout Action: refresh product stock
  const handleOrderProcessed = (order: Order) => {
    // Redraw and reload catalog products to reflect modified stock allocations
    fetchProducts();
    showToast(`Transaction authorized! Ref: ${order.id}`);
  };

  // Reset database completely
  const handleDatabaseReset = async () => {
    if (!window.confirm("Are you sure you want to reset the catalog database back to initial defaults?")) {
      return;
    }
    try {
      const res = await fetch("/api/db/reset", { method: "POST" });
      if (res.ok) {
        fetchProducts();
        handleClearCart();
        setUser(null);
        setToken(null);
        showToast("Database seeded and storage flushed.");
      }
    } catch (err) {
      showToast("Store reset failed.");
    }
  };

  // Filter and search computation values
  const filteredProducts = products.filter((product) => {
    const matchCategory = selectedCategory === "all" || product.category === selectedCategory;
    const matchSearch =
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchCategory && matchSearch;
  });

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col text-gray-900">
      
      {/* Dynamic Toast feedback panel */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2 rounded-xl bg-gray-950 px-4 py-3 text-xs font-semibold text-white shadow-xl animate-bounce">
          <ShieldCheck className="h-4 w-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Nav Section */}
      <Navbar
        user={user}
        cartCount={cartItems.reduce((acc, curr) => acc + curr.quantity, 0)}
        selectedCategory={selectedCategory}
        categories={categories}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onSelectCategory={setSelectedCategory}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
        onLogout={handleLogout}
        onOpenHistory={() => setIsHistoryOpen(true)}
      />

      {/* Hero Banner Section */}
      <div className="mx-auto w-full max-w-7xl px-4 pt-8 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-3xl bg-gray-950 text-white p-8 md:p-12 shadow-sm">
          {/* Subtle design accents */}
          <div className="absolute right-0 bottom-0 top-0 w-1/2 opacity-20 hidden md:block">
            <img 
              src="https://images.unsplash.com/photo-1513151233558-d860c5398176?w=800&auto=format&fit=crop&q=80" 
              alt="Curated Studio"
              className="w-full h-full object-cover rounded-l-full scale-110 rotate-1"
            />
          </div>

          <div className="max-w-xl relative z-10 space-y-4">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-wider text-white">
              <Box className="h-3 w-3" />
              <span>Catalog Edition 2026</span>
            </span>
            
            <h2 className="font-sans text-3xl font-black tracking-tight sm:text-4xl">
              Curated Workspace Essentials
            </h2>
            
            <p className="font-sans text-xs text-gray-400 leading-relaxed max-w-md">
              A premium, hand-picked collection of tactile stationery, acoustic desktop mats, and smart layout controllers designed to unify aesthetic focus and ergonomics.
            </p>

            <div className="flex items-center gap-4 pt-2">
              <div className="flex items-center gap-1.5 text-xs text-gray-300 font-semibold">
                <ShieldCheck className="h-4 w-4 text-emerald-400" />
                <span>Encrypted Transactions</span>
              </div>
              <div className="h-4 w-px bg-white/10" />
              <div className="flex items-center gap-1.5 text-xs text-gray-300 font-semibold">
                <ShoppingBag className="h-4 w-4 text-sky-400" />
                <span>Same day Shipping</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main product listings layout space */}
      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-8 sm:px-6 lg:px-8">
        
        {/* Error reporting banner */}
        {errorMessage && (
          <div className="mb-6 rounded-2xl bg-red-50 p-4 text-xs font-semibold text-red-700 flex items-center gap-2">
            <AlertCircle className="h-5 w-5" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Categories count description */}
        <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h3 className="font-sans text-base font-bold tracking-tight text-gray-950">
              {selectedCategory === "all" ? "All Collections" : `${selectedCategory}`}
            </h3>
            <p className="font-sans text-xs text-gray-500 mt-0.5">
              Refined by {filteredProducts.length} unique matched items out of {products.length} records.
            </p>
          </div>

          {/* Quick search container (mobile visibility anchor) */}
          <div className="block sm:hidden w-full relative">
            <input
              type="text"
              placeholder="Search complete index..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-2xl border border-gray-200 py-2 pl-4 pr-4 text-xs outline-none focus:border-gray-900 bg-white"
            />
          </div>
        </div>

        {/* Loading placeholder skeleton */}
        {isLoading ? (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 py-12">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="animate-pulse rounded-2xl border border-gray-100 bg-white p-4 space-y-4">
                <div className="aspect-square w-full rounded-xl bg-gray-150" />
                <div className="h-4 w-2/3 rounded-lg bg-gray-150" />
                <div className="h-3 w-full rounded-lg bg-gray-100" />
                <div className="flex justify-between items-center pt-2">
                  <div className="h-5 w-1/3 rounded-lg bg-gray-150" />
                  <div className="h-7 w-1/4 rounded-lg bg-gray-150" />
                </div>
              </div>
            ))}
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="mx-auto py-16 text-center max-w-sm">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-gray-100 text-gray-400 mb-4">
              <ShoppingBag className="h-6 w-6" />
            </div>
            <h4 className="font-sans text-sm font-semibold text-gray-900">No matching items found</h4>
            <p className="font-sans text-xs text-gray-500 mt-1">
              Your parameters did not match any premium essentials in our curated lists. Try relaxing search queries or categories.
            </p>
            <button
              onClick={() => {
                setSearchQuery("");
                setSelectedCategory("all");
              }}
              className="mt-4 rounded-xl bg-gray-950 px-4 py-2 text-xs font-semibold text-white hover:bg-gray-850 cursor-pointer"
            >
              Exterminate Filters
            </button>
          </div>
        ) : (
          /* Actual active products render grid grid */
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onViewDetails={setSelectedProduct}
                onAddToCart={(prod) => handleAddToCart(prod, 1)}
                isOutOfStock={product.stock <= 0}
              />
            ))}
          </div>
        )}
      </main>

      {/* Footer Branding Panel */}
      <footer className="border-t border-gray-100 bg-white/70 backdrop-blur-md py-10 mt-12 text-center text-xs space-y-4">
        <div className="mx-auto max-w-7xl px-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-left space-y-1">
            <h2 className="font-sans text-sm font-bold text-gray-900">E-Commerce Store</h2>
            <p className="text-gray-500 leading-relaxed text-[11px] max-w-md">
              A responsive architectural showcase, combining a local state Express.js pipeline database with custom product assets and transactions managers.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleDatabaseReset}
              className="flex items-center gap-1 px-3 py-1.5 text-xs text-gray-600 hover:text-red-700 hover:border-red-200 transition-colors border border-gray-150 rounded-lg bg-gray-50"
              title="Reset stock and orders logs"
            >
              <RefreshCw className="h-3 w-3" />
              <span>Reset Catalog DB</span>
            </button>
          </div>
        </div>

        <div className="border-t border-gray-50 pt-4 font-mono text-[10px] text-gray-400">
          © 2026 E-Commerce Store. Safeguarded in sandboxed workspace containment.
        </div>
      </footer>

      {/* OVERLAY MODALS ROUTERS */}
      
      {/* Product Information Detail Modal */}
      {selectedProduct && (
        <ProductDetailModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
          onAddToCart={handleAddToCart}
        />
      )}

      {/* Shopping Cart Drawer Dialog */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateCartQuantity={handleUpdateCartQuantity}
        onRemoveFromCart={handleRemoveFromCart}
        user={user}
        onOpenAuth={() => {
          setIsCartOpen(false);
          setIsAuthOpen(true);
        }}
        onClearCart={handleClearCart}
        onOrderProcessed={handleOrderProcessed}
      />

      {/* Access credentials Auth Modal Popup */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onSuccess={handleAuthSuccess}
      />

      {/* User ledger records history tracker */}
      <OrderHistory
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        user={user}
      />

    </div>
  );
}
