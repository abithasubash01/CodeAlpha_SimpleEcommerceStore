import React, { useState } from "react";
import { X, Star, ShoppingCart, Plus, Minus, Tag, Box } from "lucide-react";
import { Product } from "../types";

interface ProductDetailModalProps {
  product: Product;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number) => void;
}

export default function ProductDetailModal({
  product,
  onClose,
  onAddToCart
}: ProductDetailModalProps) {
  const [quantity, setQuantity] = useState(1);
  const isOutOfStock = product.stock <= 0;

  const handleIncrement = () => {
    if (quantity < product.stock) {
      setQuantity((q) => q + 1);
    }
  };

  const handleDecrement = () => {
    if (quantity > 1) {
      setQuantity((q) => q - 1);
    }
  };

  const handleAddSubmit = () => {
    onAddToCart(product, quantity);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-950/40 backdrop-blur-xs">
      <div className="relative w-full max-w-3xl overflow-hidden rounded-2xl bg-white shadow-2xl animate-in fade-in zoom-in duration-200">
        
        {/* Close Button Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 flex h-8 w-8 items-center justify-center rounded-full bg-white/80 backdrop-blur-xs border border-gray-100 text-gray-500 hover:text-gray-900 shadow-sm transition-transform hover:scale-105 active:scale-95 cursor-pointer"
        >
          <X className="h-4 w-4" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          
          {/* Left panel: Media */}
          <div className="relative aspect-square md:aspect-auto md:h-[450px] bg-gray-50">
            <img
              src={product.image}
              alt={product.name}
              referrerPolicy="no-referrer"
              className="h-full w-full object-cover object-center"
            />
            <div className="absolute bottom-4 left-4">
              <span className="flex items-center gap-1.5 rounded-full bg-gray-950/80 backdrop-blur-xs px-3 py-1 font-sans text-[11px] font-semibold text-white">
                <Tag className="h-3.5 w-3.5" />
                {product.category}
              </span>
            </div>
          </div>

          {/* Right panel: Information */}
          <div className="flex flex-col p-6 min-h-[350px] md:h-[450px] overflow-y-auto">
            {/* Header */}
            <div>
              <h2 className="font-sans text-xl font-bold tracking-tight text-gray-950">
                {product.name}
              </h2>

              {/* Rating state block */}
              {product.rating && (
                <div className="mt-2 flex items-center gap-2">
                  <div className="flex text-amber-400">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${
                          i < Math.round(product.rating!.rate) ? "fill-amber-400" : "text-gray-200"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="font-sans text-xs font-semibold text-gray-700">
                    {product.rating.rate.toFixed(1)} / 5.0
                  </span>
                  <span className="font-sans text-xs text-gray-400">
                    ({product.rating.count} reviews)
                  </span>
                </div>
              )}
            </div>

            {/* Description */}
            <div className="mt-4 flex-1">
              <p className="font-sans text-xs text-gray-600 leading-relaxed">
                {product.description}
              </p>

              {/* Features Lists if defined */}
              {product.features && product.features.length > 0 && (
                <div className="mt-4">
                  <h4 className="font-sans text-xs font-semibold uppercase tracking-wider text-gray-400">
                    Highlights
                  </h4>
                  <ul className="mt-1.5 space-y-1">
                    {product.features.map((feature, i) => (
                      <li key={i} className="flex items-center gap-1.5 font-sans text-xs text-gray-700">
                        <span className="h-1.5 w-1.5 rounded-full bg-gray-950" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* Price and Stock Status Footer Layer */}
            <div className="mt-6 border-t border-gray-100 pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-sans text-[10px] uppercase font-bold tracking-wider text-gray-400">Unit Price</span>
                  <p className="font-mono text-2xl font-black text-gray-950">${product.price.toFixed(2)}</p>
                </div>

                <div className="text-right">
                  <span className="font-sans text-[10px] uppercase font-bold tracking-wider text-gray-400">Stock Availability</span>
                  <div className="flex items-center gap-1 mt-0.5 justify-end">
                    <Box className="h-3.5 w-3.5 text-gray-400" />
                    <span className={`font-mono text-xs font-bold leading-none ${isOutOfStock ? "text-red-600" : "text-emerald-700"}`}>
                      {isOutOfStock ? "Sold Out" : `${product.stock} units available`}
                    </span>
                  </div>
                </div>
              </div>

              {/* Quantity selectors and cart submission */}
              <div className="mt-5 flex items-center gap-3">
                {!isOutOfStock ? (
                  <>
                    <div className="flex items-center rounded-xl border border-gray-200 p-1 bg-gray-50/50">
                      <button
                        onClick={handleDecrement}
                        disabled={quantity <= 1}
                        className="flex h-8 w-8 items-center justify-center rounded-lg text-gray-600 hover:bg-white hover:text-gray-900 disabled:opacity-40 transition-colors cursor-pointer"
                      >
                        <Minus className="h-3 w-3" />
                      </button>
                      
                      <span className="w-10 text-center font-mono text-xs font-bold text-gray-900">
                        {quantity}
                      </span>

                      <button
                        onClick={handleIncrement}
                        disabled={quantity >= product.stock}
                        className="flex h-8 w-8 items-center justify-center rounded-lg text-gray-600 hover:bg-white hover:text-gray-900 disabled:opacity-40 transition-colors cursor-pointer"
                      >
                        <Plus className="h-3 w-3" />
                      </button>
                    </div>

                    <button
                      onClick={handleAddSubmit}
                      className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-gray-950 py-3 text-xs font-semibold text-white shadow-md hover:bg-gray-850 active:scale-98 transition-transform cursor-pointer"
                    >
                      <ShoppingCart className="h-4 w-4" />
                      <span>Add {quantity} to Cart</span>
                    </button>
                  </>
                ) : (
                  <div className="w-full text-center rounded-xl bg-red-50 py-3 text-xs font-semibold text-red-700">
                    This beautiful custom selection is currently unavailable.
                  </div>
                )}
              </div>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
}
