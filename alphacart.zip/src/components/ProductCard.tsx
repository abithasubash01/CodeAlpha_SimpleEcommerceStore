import React from "react";
import { Star, Eye, Plus, CheckCircle } from "lucide-react";
import { Product } from "../types";

interface ProductCardProps {
  product: Product;
  onViewDetails: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  isOutOfStock: boolean;
}

export default function ProductCard({
  product,
  onViewDetails,
  onAddToCart,
  isOutOfStock
}: ProductCardProps) {
  return (
    <div className="group relative flex flex-col overflow-hidden rounded-2xl border border-gray-100 bg-white transition-all duration-300 hover:border-gray-200 hover:shadow-lg hover:shadow-gray-100">
      
      {/* Category & Badge */}
      <div className="absolute top-3 left-3 z-10">
        <span className="rounded-full bg-white/90 backdrop-blur-xs px-2.5 py-0.5 font-sans text-[10px] font-semibold tracking-wide text-gray-800 uppercase shadow-xs">
          {product.category}
        </span>
      </div>

      {/* Stock warning */}
      {isOutOfStock && (
        <div className="absolute top-3 right-3 z-10">
          <span className="rounded-full bg-red-500 px-2 py-0.5 font-mono text-[9px] font-bold tracking-wide text-white uppercase shadow-xs">
            Out of Stock
          </span>
        </div>
      )}
      {!isOutOfStock && product.stock <= 5 && (
        <div className="absolute top-3 right-3 z-10">
          <span className="rounded-full bg-amber-500 px-2 py-0.5 font-mono text-[9px] font-bold tracking-wide text-white uppercase shadow-xs">
            Only {product.stock} Left
          </span>
        </div>
      )}

      {/* Product Image Panel */}
      <div 
        onClick={() => onViewDetails(product)}
        className="relative aspect-square w-full overflow-hidden bg-gray-50 cursor-pointer"
      >
        <img
          src={product.image}
          alt={product.name}
          referrerPolicy="no-referrer"
          className="h-full w-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
        />
        {/* Hover Overlay */}
        <div className="absolute inset-0 bg-black/10 opacity-0 transition-opacity group-hover:opacity-100 flex items-center justify-center">
          <button className="flex h-10 w-10 items-center justify-center rounded-full bg-white text-gray-900 shadow-md transition-transform hover:scale-110 active:scale-95">
            <Eye className="h-5 w-5" />
          </button>
        </div>
      </div>

      {/* Text Details Area */}
      <div className="flex flex-1 flex-col p-4">
        {/* Rating state */}
        {product.rating && (
          <div className="mb-1 flex items-center gap-1">
            <div className="flex text-amber-500">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className={`h-3 w-3 ${
                    i < Math.floor(product.rating!.rate) ? "fill-amber-400" : "text-gray-200"
                  }`}
                />
              ))}
            </div>
            <span className="font-sans text-[10px] text-gray-500">
              ({product.rating.count})
            </span>
          </div>
        )}

        <h3 
          onClick={() => onViewDetails(product)}
          className="cursor-pointer font-sans text-sm font-semibold tracking-tight text-gray-900 line-clamp-1 group-hover:text-gray-950"
        >
          {product.name}
        </h3>

        <p className="mt-1 flex-1 font-sans text-xs text-gray-500 line-clamp-2 leading-relaxed">
          {product.description}
        </p>

        {/* Action and Price row */}
        <div className="mt-4 flex items-center justify-between border-t border-gray-50 pt-3">
          <div className="flex flex-col">
            <span className="text-[10px] uppercase font-mono tracking-wider text-gray-400">Price</span>
            <span className="font-mono text-base font-bold text-gray-950">${product.price.toFixed(2)}</span>
          </div>

          <button
            onClick={() => onAddToCart(product)}
            disabled={isOutOfStock}
            className={`flex items-center gap-1.5 rounded-xl px-3 py-1.5 font-sans text-xs font-semibold cursor-pointer transition-all ${
              isOutOfStock
                ? "bg-gray-100 text-gray-400 cursor-not-allowed"
                : "bg-gray-950 text-white hover:bg-gray-850 shadow-sm active:scale-95"
            }`}
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Add to Cart</span>
          </button>
        </div>
      </div>
    </div>
  );
}
