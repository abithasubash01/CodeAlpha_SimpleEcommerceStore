import React from "react";
import { ShoppingCart, User, LogOut, History, Search } from "lucide-react";
import { User as UserType } from "../types";

interface NavbarProps {
  user: UserType | null;
  cartCount: number;
  selectedCategory: string;
  categories: string[];
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onSelectCategory: (category: string) => void;
  onOpenCart: () => void;
  onOpenAuth: () => void;
  onLogout: () => void;
  onOpenHistory: () => void;
}

export default function Navbar({
  user,
  cartCount,
  selectedCategory,
  categories,
  searchQuery,
  onSearchChange,
  onSelectCategory,
  onOpenCart,
  onOpenAuth,
  onLogout,
  onOpenHistory
}: NavbarProps) {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-gray-100 bg-white/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        
        {/* Logo */}
        <div className="flex items-center gap-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gray-950 text-white">
            <ShoppingCart className="h-5 w-5" />
          </div>
          <div>
            <h1 className="font-sans text-xl font-bold tracking-tight text-gray-900">
              E-Commerce Store
            </h1>
            <p className="font-mono text-[9px] uppercase tracking-wider text-gray-400">
              Curated Essentials
            </p>
          </div>
        </div>

        {/* Search Input */}
        <div className="relative hidden max-w-md flex-1 px-4 sm:block md:max-w-lg">
          <div className="pointer-events-none absolute inset-y-0 left-7 flex items-center text-gray-400">
            <Search className="h-4 w-4" />
          </div>
          <input
            type="text"
            placeholder="Search our collection of custom items..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full rounded-full border border-gray-200 py-1.5 pl-10 pr-4 text-xs tracking-tight placeholder-gray-400 outline-none transition-all focus:border-gray-900 focus:ring-1 focus:ring-gray-900 bg-gray-50/50"
          />
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-3">
          {/* User Section */}
          {user ? (
            <div className="flex items-center gap-2">
              <button
                onClick={onOpenHistory}
                className="group flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 font-sans text-xs font-medium text-gray-600 transition-colors hover:bg-gray-50 hover:text-gray-900"
                title="View Orders"
              >
                <History className="h-4 w-4 text-gray-400 group-hover:text-gray-900" />
                <span className="hidden md:inline">My Orders</span>
              </button>

              <div className="flex items-center gap-2 border-l border-gray-100 pl-3">
                <span className="hidden select-none font-sans text-xs font-semibold text-gray-800 lg:inline">
                  Hi, {user.name || user.username}
                </span>
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-gray-100 text-xs font-bold uppercase text-gray-700">
                  {user.username.slice(0, 2)}
                </span>
                <button
                  onClick={onLogout}
                  className="rounded-lg p-1.5 text-gray-400 transition-colors hover:bg-red-50 hover:text-red-600"
                  title="Logout"
                >
                  <LogOut className="h-4 w-4" />
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              className="flex items-center gap-1.5 rounded-full bg-gray-900 px-4 py-1.5 font-sans text-xs font-medium text-white shadow-sm transition-all hover:bg-gray-850"
            >
              <User className="h-3.5 w-3.5" />
              <span>Login / Sign Up</span>
            </button>
          )}

          {/* Cart Icon Button */}
          <button
            onClick={onOpenCart}
            className="relative flex h-10 w-10 items-center justify-center rounded-full border border-gray-100 bg-white shadow-xs transition-transform hover:scale-[1.03] active:scale-[0.98] cursor-pointer"
          >
            <ShoppingCart className="h-4 w-4 text-gray-800" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-gray-900 font-mono text-[10px] font-bold text-white shadow-xs animate-bounce">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Sub-Header Categories Selector */}
      <div className="border-t border-gray-50 bg-gray-50/50">
        <div className="mx-auto flex max-w-7xl items-center gap-2 overflow-x-auto px-4 py-2 sm:px-6 lg:px-8 scrollbar-none">
          <button
            onClick={() => onSelectCategory("all")}
            className={`cursor-pointer rounded-full px-4 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
              selectedCategory === "all"
                ? "bg-gray-950 text-white"
                : "bg-white text-gray-600 border border-gray-150 hover:text-gray-900"
            }`}
          >
            All Products
          </button>
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => onSelectCategory(category)}
              className={`cursor-pointer rounded-full px-4 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
                selectedCategory === category
                  ? "bg-gray-950 text-white"
                  : "bg-white text-gray-600 border border-gray-150 hover:text-gray-900"
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>
    </header>
  );
}
