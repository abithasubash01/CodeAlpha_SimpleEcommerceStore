import React, { useState, useEffect } from "react";
import { X, Clock, MapPin, Truck, Check, RefreshCw, Box, AlertCircle } from "lucide-react";
import { Order, User } from "../types";

interface OrderHistoryProps {
  isOpen: boolean;
  onClose: () => void;
  user: User | null;
}

export default function OrderHistory({ isOpen, onClose, user }: OrderHistoryProps) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && user) {
      fetchOrders();
    }
  }, [isOpen, user]);

  const fetchOrders = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/orders/user/${user?.id}`);
      if (!res.ok) throw new Error("Could not load your historical orders.");
      const data = await res.json();
      // Sort orders descending by createdAt
      setOrders(data.sort((a: Order, b: Order) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
    } catch (err: any) {
      setError(err.message || "Something went wrong.");
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-950/40 backdrop-blur-xs">
      <div className="relative w-full max-w-2xl overflow-hidden rounded-2xl bg-white shadow-2xl p-6 border border-gray-100 flex flex-col max-h-[85vh] animate-in fade-in zoom-in duration-200">
        
        {/* Header Exit */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-900 duration-150 p-1 hover:bg-gray-50 rounded-full cursor-pointer"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Info Area heading */}
        <div className="mb-4">
          <h2 className="font-sans text-lg font-bold tracking-tight text-gray-950">
            Order Settlement Log
          </h2>
          <p className="font-sans text-xs text-gray-500 mt-1">
            Review detailed transactions and distribution statuses for account: <strong className="text-gray-700">{user?.email}</strong>
          </p>
        </div>

        {/* Content Logs listing */}
        <div className="flex-1 overflow-y-auto min-h-0 space-y-4 pr-1">
          {isLoading ? (
            <div className="py-12 flex flex-col justify-center items-center text-gray-400">
              <RefreshCw className="h-7 w-7 animate-spin mb-2" />
              <span className="font-sans text-xs">Accessing your safe records...</span>
            </div>
          ) : error ? (
            <div className="rounded-xl bg-red-50 p-4 text-xs font-semibold text-red-700 flex items-start gap-2">
              <AlertCircle className="h-4 w-4" />
              <span>{error}</span>
            </div>
          ) : orders.length === 0 ? (
            <div className="py-12 text-center text-gray-500">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-gray-50 text-gray-400 mb-3">
                <Box className="h-6 w-6" />
              </div>
              <p className="font-sans text-xs font-semibold text-gray-800">No transactions recorded yet</p>
              <p className="font-sans text-[11px] text-gray-455 mt-1">Orders you complete will be captured and visible here securely.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {orders.map((order) => (
                <div 
                  key={order.id}
                  className="rounded-xl border border-gray-100 bg-gray-50/10 p-4 hover:bg-gray-50/35 transition-colors space-y-3"
                >
                  {/* Ledger Details Row */}
                  <div className="flex flex-wrap items-center justify-between border-b border-gray-100 pb-2.5 gap-2">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold text-gray-950">{order.id}</span>
                      <span className="text-[10px] font-sans text-gray-400">
                        {new Date(order.createdAt).toLocaleDateString()} at {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>

                    {/* Status badges */}
                    <div className="flex items-center gap-1.5 text-xs font-semibold">
                      {order.status === "Pending" && (
                        <span className="flex items-center gap-1.5 rounded-full bg-amber-50 px-2 py-0.5 text-amber-700 font-sans text-[10px]">
                          <Clock className="h-3 w-3" />
                          <span>Processing</span>
                        </span>
                      )}
                      {order.status === "Processing" && (
                        <span className="flex items-center gap-1.5 rounded-full bg-blue-50 px-2 py-0.5 text-blue-700 font-sans text-[10px]">
                          <Clock className="h-3 w-3" />
                          <span>Assembling</span>
                        </span>
                      )}
                      {order.status === "Shipped" && (
                        <span className="flex items-center gap-1.5 rounded-full bg-indigo-50 px-2 py-0.5 text-indigo-700 font-sans text-[10px]">
                          <Truck className="h-3 w-3" />
                          <span>Dispatched</span>
                        </span>
                      )}
                      {order.status === "Completed" && (
                        <span className="flex items-center gap-1.5 rounded-full bg-emerald-50 px-2 py-0.5 text-emerald-700 font-sans text-[10px]">
                          <Check className="h-3 w-3" />
                          <span>Delivered</span>
                        </span>
                      )}
                    </div>
                  </div>

                  {/* List of items */}
                  <div className="space-y-2">
                    {order.items.map((item, i) => (
                      <div key={i} className="flex items-center gap-3">
                        <img
                          src={item.image}
                          alt={item.name}
                          referrerPolicy="no-referrer"
                          className="h-8 w-8 rounded-md object-cover bg-gray-50"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="font-sans text-xs font-semibold text-gray-800 truncate">{item.name}</p>
                          <p className="font-mono text-[10px] text-gray-450">Qty: {item.quantity} × ${item.price.toFixed(2)}</p>
                        </div>
                        <span className="font-mono text-xs font-bold text-right text-gray-800">
                          ${(item.price * item.quantity).toFixed(2)}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Address + settlement details row */}
                  <div className="flex flex-wrap border-t border-gray-100 pt-3 justify-between items-start gap-3">
                    <div className="flex items-start gap-1 max-w-[340px]">
                      <MapPin className="h-3.5 w-3.5 mt-0.5 text-gray-400" />
                      <div>
                        <p className="font-sans text-xs text-gray-800 font-medium leading-none mb-1">
                          {order.shippingAddress.fullName}
                        </p>
                        <p className="font-sans text-[10px] text-gray-500 leading-tight">
                          {order.shippingAddress.address}, {order.shippingAddress.city}, {order.shippingAddress.postalCode}, {order.shippingAddress.country}
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="font-mono text-[9px] text-gray-400 font-bold block uppercase">
                        Settled via {order.paymentMethod}
                      </span>
                      <span className="font-mono text-sm font-black text-gray-950">
                        Total Paid: ${order.totalAmount.toFixed(2)}
                      </span>
                    </div>
                  </div>

                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer controls */}
        <div className="mt-4 border-t border-gray-100 pt-3 flex items-center justify-between">
          <button
            onClick={fetchOrders}
            className="flex items-center gap-1 px-3 py-1.5 text-xs text-gray-500 hover:text-gray-950 transition-colors border border-gray-150 rounded-lg bg-white"
          >
            <RefreshCw className="h-3 w-3" />
            <span>Refurbish Records</span>
          </button>
          
          <button
            onClick={onClose}
            className="rounded-lg bg-gray-950 text-white font-sans text-xs font-semibold px-4 py-1.5 hover:bg-gray-850 cursor-pointer"
          >
            Dismiss Log
          </button>
        </div>

      </div>
    </div>
  );
}
