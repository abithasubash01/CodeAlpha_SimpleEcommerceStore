import React, { useState } from "react";
import { X, Trash2, ShoppingBag, ArrowRight, CreditCard, Ship, Check, ArrowLeft, RefreshCw, AlertCircle } from "lucide-react";
import { CartItem, Product, Order, User } from "../types";

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateCartQuantity: (product: Product, quantity: number) => void;
  onRemoveFromCart: (product: Product) => void;
  user: User | null;
  onOpenAuth: () => void;
  onClearCart: () => void;
  onOrderProcessed: (order: Order) => void;
}

type DrawerStep = 'cart' | 'checkout' | 'success';

export default function CartDrawer({
  isOpen,
  onClose,
  cartItems,
  onUpdateCartQuantity,
  onRemoveFromCart,
  user,
  onOpenAuth,
  onClearCart,
  onOrderProcessed
}: CartDrawerProps) {
  const [step, setStep] = useState<DrawerStep>('cart');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [generatedOrder, setGeneratedOrder] = useState<Order | null>(null);

  // Form states initial state populated if logged-in user exists
  const [fullName, setFullName] = useState(user?.name || "");
  const [address, setAddress] = useState(user?.address || "");
  const [city, setCity] = useState("");
  const [postalCode, setPostalCode] = useState("");
  const [country, setCountry] = useState("India");
  const [paymentMethod, setPaymentMethod] = useState("Credit Card");

  // Autofill if user logging changes
  React.useEffect(() => {
    if (user) {
      if (!fullName) setFullName(user.name || "");
      if (!address) setAddress(user.address || "");
    }
  }, [user]);

  if (!isOpen) return null;

  const totalItemCount = cartItems.reduce((acc, curr) => acc + curr.quantity, 0);
  const itemTotal = cartItems.reduce((acc, curr) => acc + curr.product.price * curr.quantity, 0);
  const shippingFee = itemTotal > 150 ? 0 : 15.0;
  const grandTotal = itemTotal + shippingFee;

  const handleCheckoutSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !address || !city || !postalCode || !country) {
      setSubmitError("Please fill out all shipping details.");
      return;
    }

    setIsSubmitting(true);
    setSubmitError(null);

    try {
      const orderPayload = {
        userId: user?.id || "guest-session",
        items: cartItems.map(item => ({
          productId: item.product.id,
          name: item.product.name,
          price: item.product.price,
          quantity: item.quantity,
          image: item.product.image
        })),
        shippingAddress: {
          fullName,
          address,
          city,
          postalCode,
          country
        },
        paymentMethod,
        totalAmount: grandTotal
      };

      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(orderPayload)
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Could not process order.");
      }

      const completedOrder: Order = await res.ok ? await res.json() : null;
      if (completedOrder) {
        setGeneratedOrder(completedOrder);
        onOrderProcessed(completedOrder);
        onClearCart();
        setStep('success');
      }
    } catch (err: any) {
      setSubmitError(err.message || "An unexpected error occurred during processing.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    setStep('cart');
    setGeneratedOrder(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-gray-950/40 backdrop-blur-xs">
      {/* Click outside to close (only if not currently submitting/success status) */}
      <div 
        className="flex-1 cursor-pointer"
        onClick={() => {
          if (!isSubmitting && step !== 'success') onClose();
        }}
      />

      <div className="relative w-full max-w-md bg-white h-screen shadow-2xl flex flex-col animate-in slide-in-from-right duration-250">
        
        {/* Header Drawer banner */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <ShoppingBag className="h-4 w-4 text-gray-950" />
            <h2 className="font-sans text-base font-bold tracking-tight text-gray-950">
              {step === 'cart' && `Shopping Cart (${totalItemCount})`}
              {step === 'checkout' && "Secure Checkout"}
              {step === 'success' && "Order Secured"}
            </h2>
          </div>
          {step !== 'success' && (
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-900 duration-150 rounded-full p-1 hover:bg-gray-50 cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>
          )}
        </div>

        {/* STEP 1: CART DISPLAY */}
        {step === 'cart' && (
          <>
            <div className="flex-1 overflow-y-auto px-6 py-4">
              {cartItems.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center">
                  <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gray-50 text-gray-400 mb-4 animate-pulse">
                    <ShoppingBag className="h-7 w-7" />
                  </div>
                  <h3 className="font-sans text-sm font-semibold text-gray-900">Your cart is empty</h3>
                  <p className="font-sans text-xs text-gray-500 mt-1 max-w-[240px]">
                    Looks like you haven't added any luxury essentials to your cart yet.
                  </p>
                  <button
                    onClick={onClose}
                    className="mt-4 rounded-xl bg-gray-900 text-white font-sans text-xs font-semibold px-4 py-2 cursor-pointer hover:bg-gray-800"
                  >
                    Browse Items
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {cartItems.map((item) => (
                    <div 
                      key={item.product.id}
                      className="flex items-start gap-4 rounded-xl border border-gray-50 p-3 bg-gray-50/30 hover:bg-gray-50/50 transition-colors"
                    >
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        referrerPolicy="no-referrer"
                        className="h-14 w-14 rounded-lg object-cover object-center bg-gray-100 flex-shrink-0"
                      />
                      
                      <div className="flex-1 min-w-0">
                        <h4 className="font-sans text-xs font-bold text-gray-900 truncate">
                          {item.product.name}
                        </h4>
                        <p className="font-sans text-[10px] text-gray-500 uppercase font-mono tracking-wider">
                          {item.product.category}
                        </p>
                        
                        {/* Quantity and controls */}
                        <div className="flex items-center gap-2 mt-2">
                          <div className="flex items-center rounded-lg border border-gray-200 p-0.5 bg-white">
                            <button
                              onClick={() => onUpdateCartQuantity(item.product, item.quantity - 1)}
                              className="h-5 w-5 flex items-center justify-center text-gray-500 hover:text-gray-900 text-[10px] cursor-pointer"
                            >
                              -
                            </button>
                            <span className="w-6 text-center font-mono text-[11px] font-bold text-gray-900">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => onUpdateCartQuantity(item.product, item.quantity + 1)}
                              className="h-5 w-5 flex items-center justify-center text-gray-500 hover:text-gray-900 text-[10px] cursor-pointer"
                            >
                              +
                            </button>
                          </div>

                          <button
                            onClick={() => onRemoveFromCart(item.product)}
                            className="text-gray-400 hover:text-red-600 transition-colors p-1 rounded-md hover:bg-red-50 cursor-pointer"
                            title="Remove"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>

                      <div className="text-right flex-shrink-0">
                        <p className="font-mono text-xs font-bold text-gray-900">
                          ${(item.product.price * item.quantity).toFixed(2)}
                        </p>
                        <p className="font-mono text-[9px] text-gray-400">
                          ${item.product.price.toFixed(2)} ea
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Cart Footer */}
            {cartItems.length > 0 && (
              <div className="border-t border-gray-100 bg-gray-50/50 p-6 space-y-4">
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs text-gray-600">
                    <span>Subtotal</span>
                    <span className="font-mono">${itemTotal.toFixed(2)}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-gray-600">
                    <span>Shipping</span>
                    <span className="font-mono">
                      {shippingFee === 0 ? "FREE" : `$${shippingFee.toFixed(2)}`}
                    </span>
                  </div>
                  {shippingFee > 0 && (
                    <p className="font-sans text-[10px] text-amber-600 font-medium">
                      Add ${(150 - itemTotal).toFixed(2)} more for FREE shipping!
                    </p>
                  )}
                  <div className="flex items-center justify-between text-sm font-bold text-gray-900 border-t border-gray-250 pt-2 mt-1">
                    <span>Total Amount</span>
                    <span className="font-mono">${grandTotal.toFixed(2)}</span>
                  </div>
                </div>

                {!user && (
                  <div className="rounded-xl bg-amber-50 p-3 text-amber-800 text-[11px] leading-relaxed flex items-start gap-1.5">
                    <AlertCircle className="h-4 w-4 flex-shrink-0 mt-0.5 text-amber-600" />
                    <div>
                      <span>You are checking out as a <strong>Guest</strong>. Log in to claim benefits and save coordinates. </span>
                      <button 
                        onClick={onOpenAuth}
                        className="underline text-amber-950 font-semibold ml-1 cursor-pointer"
                      >
                        Login here
                      </button>
                    </div>
                  </div>
                )}

                <button
                  onClick={() => setStep('checkout')}
                  className="w-full flex items-center justify-center gap-2 rounded-xl bg-gray-950 py-3 text-xs font-semibold text-white shadow-md hover:bg-gray-850 transition-transform active:scale-98 cursor-pointer"
                >
                  <span>Proceed to Shipping</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>
              </div>
            )}
          </>
        )}

        {/* STEP 2: CHECKOUT INFO FORM */}
        {step === 'checkout' && (
          <form onSubmit={handleCheckoutSubmit} className="flex-1 flex flex-col min-h-0">
            <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
              <button
                type="button"
                onClick={() => setStep('cart')}
                className="flex items-center gap-1 text-xs text-gray-500 hover:text-gray-900 mb-2 cursor-pointer"
              >
                <ArrowLeft className="h-3 h-3" />
                <span>Back to Cart</span>
              </button>

              <div className="space-y-3">
                <h3 className="font-sans text-xs font-bold uppercase tracking-wider text-gray-400">
                  Shipping Destination
                </h3>

                <div className="space-y-3 bg-gray-50/50 rounded-xl border border-gray-100 p-4">
                  <div>
                    <label className="block font-sans text-[10px] font-bold uppercase text-gray-700">
                      Receiver Name
                    </label>
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="e.g. Abitha Subash"
                      className="mt-1 w-full rounded-lg border border-gray-200 bg-white px-3 py-1.5 font-sans text-xs outline-none transition-all focus:border-gray-900"
                    />
                  </div>

                  <div>
                    <label className="block font-sans text-[10px] font-bold uppercase text-gray-700">
                      Postal Address
                    </label>
                    <input
                      type="text"
                      required
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder="Street address, apartment, suite"
                      className="mt-1 w-full rounded-lg border border-gray-200 bg-white px-3 py-1.5 font-sans text-xs outline-none transition-all focus:border-gray-900"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-sans text-[10px] font-bold uppercase text-gray-700">
                        City
                      </label>
                      <input
                        type="text"
                        required
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        placeholder="e.g. Bangalore"
                        className="mt-1 w-full rounded-lg border border-gray-200 bg-white px-3 py-1.5 font-sans text-xs outline-none transition-all focus:border-gray-900"
                      />
                    </div>
                    <div>
                      <label className="block font-sans text-[10px] font-bold uppercase text-gray-700">
                        Postal Code
                      </label>
                      <input
                        type="text"
                        required
                        value={postalCode}
                        onChange={(e) => setPostalCode(e.target.value)}
                        placeholder="e.g. 560001"
                        className="mt-1 w-full rounded-lg border border-gray-200 bg-white px-3 py-1.5 font-sans text-xs outline-none transition-all focus:border-gray-900"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block font-sans text-[10px] font-bold uppercase text-gray-700">
                      Country
                    </label>
                    <input
                      type="text"
                      required
                      value={country}
                      onChange={(e) => setCountry(e.target.value)}
                      placeholder="e.g. India"
                      className="mt-1 w-full rounded-lg border border-gray-200 bg-white px-3 py-1.5 font-sans text-xs outline-none transition-all focus:border-gray-900"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <h3 className="font-sans text-xs font-bold uppercase tracking-wider text-gray-400">
                  Secure Settlement
                </h3>
                
                <div className="grid grid-cols-2 gap-3">
                  <label className={`flex flex-col items-center justify-center p-3 rounded-xl border cursor-pointer transition-all ${
                    paymentMethod === "Credit Card"
                      ? "border-gray-950 bg-gray-950/5 text-gray-900"
                      : "border-gray-200 bg-white text-gray-600 hover:border-gray-300"
                  }`}>
                    <input
                      type="radio"
                      name="payment"
                      value="Credit Card"
                      checked={paymentMethod === "Credit Card"}
                      onChange={() => setPaymentMethod("Credit Card")}
                      className="sr-only"
                    />
                    <CreditCard className="h-4 w-4 mb-1" />
                    <span className="font-sans font-medium text-[11px]">Card Settlement</span>
                  </label>

                  <label className={`flex flex-col items-center justify-center p-3 rounded-xl border cursor-pointer transition-all ${
                    paymentMethod === "Cash on Delivery"
                      ? "border-gray-950 bg-gray-950/5 text-gray-900"
                      : "border-gray-200 bg-white text-gray-600 hover:border-gray-300"
                  }`}>
                    <input
                      type="radio"
                      name="payment"
                      value="Cash on Delivery"
                      checked={paymentMethod === "Cash on Delivery"}
                      onChange={() => setPaymentMethod("Cash on Delivery")}
                      className="sr-only"
                    />
                    <Ship className="h-4 w-4 mb-1" />
                    <span className="font-sans font-medium text-[11px]">Pay on Delivery</span>
                  </label>
                </div>
              </div>

              {submitError && (
                <div className="rounded-xl bg-red-50 p-3 text-xs font-medium text-red-600 flex items-start gap-1.5">
                  <AlertCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                  <span>{submitError}</span>
                </div>
              )}
            </div>

            <div className="border-t border-gray-100 bg-gray-50/50 p-6 space-y-3">
              <div className="flex items-center justify-between text-xs font-medium text-gray-800">
                <span>Total Due Settlement</span>
                <span className="font-mono text-sm font-extrabold text-gray-950">${grandTotal.toFixed(2)}</span>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full flex items-center justify-center gap-2 rounded-xl bg-gray-950 py-3 text-xs font-semibold text-white shadow-md hover:bg-gray-850 active:scale-98 transition-transform cursor-pointer disabled:opacity-55"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                    <span>Authorizing Order...</span>
                  </>
                ) : (
                  <>
                    <Check className="h-3.5 w-3.5 animate-pulse" />
                    <span>Authorize Order Settlement</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}

        {/* STEP 3: SUCCESS CONFIRMATION RECEIPT */}
        {step === 'success' && generatedOrder && (
          <div className="flex-1 flex flex-col justify-between p-6">
            <div className="text-center py-6 flex-1 flex flex-col justify-center">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-emerald-50 text-emerald-600 mb-4 animate-bounce">
                <Check className="h-7 w-7" />
              </div>
              <h3 className="font-sans text-lg font-black text-gray-950">Thank you for your order!</h3>
              <p className="font-sans text-xs text-gray-500 max-w-[280px] mx-auto mt-1 leading-relaxed">
                Your settlement has been authorized safely. The curated package will begin dispatching shortly.
              </p>

              {/* Receipt Box */}
              <div className="mt-6 border border-dashed border-gray-200 rounded-xl p-4 bg-gray-50/50 text-left font-sans space-y-3 max-w-[320px] mx-auto w-full">
                <div className="flex justify-between border-b border-gray-200 border-dashed pb-2">
                  <span className="text-[10px] text-gray-400 font-bold uppercase">Order Reference</span>
                  <span className="font-mono text-xs font-bold text-gray-800">{generatedOrder.id}</span>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] text-gray-400 font-bold uppercase block">Recipient Destination</span>
                  <p className="text-xs font-semibold text-gray-800">{generatedOrder.shippingAddress.fullName}</p>
                  <p className="text-[11px] text-gray-500 leading-tight">
                    {generatedOrder.shippingAddress.address}, {generatedOrder.shippingAddress.city} - {generatedOrder.shippingAddress.postalCode}
                  </p>
                </div>

                <div className="flex justify-between items-center bg-white border border-gray-100 rounded-lg p-2">
                  <span className="text-[10px] text-gray-500 font-bold uppercase">Settled VIA</span>
                  <span className="font-sans text-[11px] font-semibold text-gray-800 uppercase">{generatedOrder.paymentMethod}</span>
                </div>

                <div className="flex justify-between border-t border-gray-200 border-dashed pt-2">
                  <span className="text-[10px] text-gray-700 font-extrabold uppercase">Paid Total</span>
                  <span className="font-mono text-xs font-black text-gray-950">${generatedOrder.totalAmount.toFixed(2)}</span>
                </div>
              </div>
            </div>

            <button
              onClick={handleReset}
              className="w-full rounded-xl bg-gray-950 py-3 text-xs font-semibold text-white hover:bg-gray-850 cursor-pointer text-center"
            >
              Continue Shopping Collection
            </button>
          </div>
        )}

      </div>
    </div>
  );
}
