import React, { useState } from "react";
import { X, Lock, Mail, User, MapPin, RefreshCw, AlertCircle } from "lucide-react";
import { User as UserType } from "../types";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: UserType, token: string) => void;
}

type AuthMode = "login" | "register";

export default function AuthModal({ isOpen, onClose, onSuccess }: AuthModalProps) {
  const [mode, setMode] = useState<AuthMode>("login");
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Form Fields
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [address, setAddress] = useState("");

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setIsLoading(true);

    try {
      let url = "/api/auth/login";
      let payload = {};

      if (mode === "login") {
        url = "/api/auth/login";
        payload = { credential: username || email, password };
      } else {
        url = "/api/auth/register";
        payload = { username, email, password, name, address };
      }

      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Authentication failed");
      }

      onSuccess(data.user, data.token);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || "Something went wrong.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleModeSwitch = (newMode: AuthMode) => {
    setMode(newMode);
    setErrorMsg(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-950/40 backdrop-blur-xs animate-fade-in">
      <div className="relative w-full max-w-md overflow-hidden rounded-2xl bg-white shadow-2xl p-6 border border-gray-100 animate-in fade-in zoom-in duration-200">
        
        {/* Absolute Exit Header */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-900 duration-150 p-1.5 hover:bg-gray-50 rounded-full cursor-pointer"
        >
          <X className="h-4.5 w-4.5" />
        </button>

        {/* Modal headers */}
        <div className="text-center mb-6">
          <div className="mx-auto flex h-10 w-10 items-center justify-center rounded-xl bg-gray-950 text-white mb-2">
            <Lock className="h-5 w-5" />
          </div>
          <h2 className="font-sans text-lg font-bold tracking-tight text-gray-950">
            {mode === "login" ? "Welcome Back" : "Create Account"}
          </h2>
          <p className="font-sans text-xs text-gray-500 mt-1">
            {mode === "login" 
              ? "Access your dashboard to review custom receipts" 
              : "Register details to fast-track subsequent orders"
            }
          </p>
        </div>

        {/* Mode switches */}
        <div className="grid grid-cols-2 rounded-xl bg-gray-100 p-1 mb-5">
          <button
            onClick={() => handleModeSwitch("login")}
            className={`rounded-lg py-1.5 text-xs font-semibold cursor-pointer transition-all ${
              mode === "login" 
                ? "bg-white text-gray-900 shadow-xs" 
                : "text-gray-500 hover:text-gray-900"
            }`}
          >
            Sign In
          </button>
          <button
            onClick={() => handleModeSwitch("register")}
            className={`rounded-lg py-1.5 text-xs font-semibold cursor-pointer transition-all ${
              mode === "register" 
                ? "bg-white text-gray-900 shadow-xs" 
                : "text-gray-500 hover:text-gray-900"
            }`}
          >
            Sign Up
          </button>
        </div>

        {/* Credentials Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          
          {mode === "login" ? (
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1">
                Username / Email Address
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-3 flex items-center text-gray-400">
                  <Mail className="h-3.5 w-3.5" />
                </span>
                <input
                  type="text"
                  required
                  placeholder="customer or customer@example.com"
                  value={username}
                  onChange={(e) => {
                    setUsername(e.target.value);
                    setEmail(e.target.value);
                  }}
                  className="w-full rounded-xl border border-gray-200 py-2 pl-9 pr-4 font-sans text-xs outline-none transition-all focus:border-gray-900"
                />
              </div>
              <p className="font-mono text-[9px] text-gray-400 mt-1">
                Tip: You can use standard <strong className="text-gray-700">customer</strong> to sign-in instantly!
              </p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1">
                    Username
                  </label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-3 flex items-center text-gray-400">
                      <User className="h-3.5 w-3.5" />
                    </span>
                    <input
                      type="text"
                      required
                      placeholder="abitha"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className="w-full rounded-xl border border-gray-200 py-2 pl-9 pr-4 font-sans text-xs outline-none transition-all focus:border-gray-900"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1">
                    Email
                  </label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-3 flex items-center text-gray-400">
                      <Mail className="h-3.5 w-3.5" />
                    </span>
                    <input
                      type="email"
                      required
                      placeholder="user@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full rounded-xl border border-gray-200 py-2 pl-9 pr-4 font-sans text-xs outline-none transition-all focus:border-gray-900"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  placeholder="Abitha Subash"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full rounded-xl border border-gray-200 py-2 px-3 font-sans text-xs outline-none transition-all focus:border-gray-900"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1">
                  Default Shipping Address
                </label>
                <div className="relative">
                  <span className="absolute top-2.5 left-3 text-gray-400">
                    <MapPin className="h-3.5 w-3.5" />
                  </span>
                  <textarea
                    rows={2}
                    placeholder="123 Main Street, Bangalore"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full rounded-xl border border-gray-200 py-2 pl-9 pr-4 font-sans text-xs outline-none transition-all focus:border-gray-900 resize-none"
                  />
                </div>
              </div>
            </>
          )}

          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1">
              Password
            </label>
            <input
              type="password"
              required
              placeholder={mode === "login" ? "password123" : "Strong password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-xl border border-gray-200 py-2 px-3 font-sans text-xs outline-none transition-all focus:border-gray-900"
            />
            {mode === "login" && (
              <p className="font-mono text-[9px] text-gray-400 mt-1">
                Tip: Standard password is <strong className="text-gray-700">password123</strong>
              </p>
            )}
          </div>

          {errorMsg && (
            <div className="rounded-xl bg-red-50 p-3 text-xs font-medium text-red-600 flex items-start gap-1.5">
              <AlertCircle className="h-4 w-4 flex-shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full flex items-center justify-center gap-2 rounded-xl bg-gray-950 py-2.5 text-xs font-semibold text-white shadow-md hover:bg-gray-850 active:scale-98 transition-transform cursor-pointer disabled:opacity-55"
          >
            {isLoading ? (
              <>
                <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                <span>Processing Authorization...</span>
              </>
            ) : (
              <span>{mode === "login" ? "Sign In Securely" : "Complete Registration"}</span>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
